; Synthetic inspection note for P701. This file is documentation, not a runnable payload.
; Rule: a report is READY only if the manifest is complete and watermark is confirmed.
section .text
global publication_gate_example
publication_gate_example:
    ; input and output are illustrative only; no system calls or memory writes
    cmp rdi, rsi              ; expected rows vs received rows
    jne .partial
    test rdx, rdx             ; watermark flag
    jz .partial
    mov eax, 1                ; 1 = READY
    ret
.partial:
    xor eax, eax              ; 0 = PARTIAL
    ret
