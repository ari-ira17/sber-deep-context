"""Synthetic validation example for P710; it never performs I/O."""
from dataclasses import dataclass

@dataclass(frozen=True)
class DeliveryManifest:
    expected_rows: int
    received_rows: int
    watermark_confirmed: bool

def publication_status(manifest: DeliveryManifest) -> str:
    if manifest.expected_rows != manifest.received_rows:
        return "PARTIAL"
    return "READY" if manifest.watermark_confirmed else "PARTIAL"
