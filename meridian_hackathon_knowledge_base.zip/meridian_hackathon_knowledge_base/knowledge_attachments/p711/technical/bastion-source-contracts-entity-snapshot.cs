// Synthetic validation example for P711; no network, file or process access.
public sealed record DeliveryManifest(int ExpectedRows, int ReceivedRows, bool WatermarkConfirmed);

public static class PublicationGate
{
    public static string Status(DeliveryManifest manifest) =>
        manifest.ExpectedRows != manifest.ReceivedRows ? "PARTIAL" :
        manifest.WatermarkConfirmed ? "READY" : "PARTIAL";
}
